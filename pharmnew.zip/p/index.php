<?php
session_start();
include 'admin/include/dbconnection.php'; 
include 'admin/include/header.php'; 
    
    if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
   
     $sql = "SELECT * FROM admin_credentials WHERE username = '$username' AND password='$password'";    
     $result = mysqli_query($con, $sql);
     
     $sqll= "SELECT * FROM users WHERE username='$username' AND password='$password'";
     $resultt = mysqli_query($con, $sqll);

     $sqlp= "SELECT * FROM pharm_user WHERE uname='$username' AND password='$password'";
     $resultp = mysqli_query($con, $sqlp);
   
     if ($result->num_rows > 0){
       echo '<script> window.location.href = "admin/index.php"; </script>';
       $row = mysqli_fetch_assoc($result);
       $_SESSION['name'] = $row['name'];
       
     }
     else if ($resultt->num_rows > 0){
       echo '<script> window.location.href = "user/index.php"; </script>';
       $row = mysqli_fetch_assoc($resultt);
       $_SESSION['fname'] = $row['fname'];
       $_SESSION['lname'] = $row['lname'];
       $_SESSION['lat'] = $row['lat'];
       $_SESSION['lng'] = $row['lng'];
     }

     else if ($resultp->num_rows > 0){
       $row = mysqli_fetch_assoc($resultp);
       $pharmid = $row['pharm_id'];


      //for fetching pharmacy name
      $sqlpt = "SELECT * FROM pharmacies WHERE ID='$pharmid'";
      $resultpt = mysqli_query($con, $sqlpt);
      $row2=mysqli_fetch_assoc($resultpt);
      $un = $row['uname'];
      
    
     echo $_SESSION['pharmname'];
       echo '<script> window.location.href = "pharmacy/index.php"; </script>';
       $_SESSION['ppd'] = $row2['ID'];
        $_SESSION['pharmname'] = $row2['pname'];
        $_SESSION['lat'] = $row2['lat'];
        $_SESSION['lng'] = $row2['lng'];
        $_SESSION['ID'] = $row2['ID'];
        $_SESSION['unn'] = $un;
        $_SESSION['userid'] = $row['ph_id'];

     }

     else{
      echo '<script type="text/javascript">
      swal({
      title: "Invalid Credentials!",
      icon: "warning",
      button: "Close",
      });
      setTimeout(function(){location.reload(1)},3000000);
      </script>';
     }
   }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>PharmVille</title>

    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="vendors/animate.css/animate.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="login" style="background-color: white">
      <div class="login_wrapper shadow p-3 mb-5" style="margin-top: 20px; border: 5px">
        <div class="row">
          <div class="col-md-12 col-sm-12">
            <div class="x_panel">
              <div class="x_title">
                <center><img src="build/images/logo.png" alt="..." width="200"></center>
                <center><h3 class="logo-caption"><span class="tweak">L</span>OGIN</h3></center>
                <div class="clearfix"></div>
              </div>
              <div class="x_content">
              <form id="" method="POST" data-parsley-validate class="form-horizontal form-label-left">
                
                
              <div class="item form-group">
                <div class="col-md-12 col-sm-12  form-group has-feedback">
                  <input type="text" class="form-control has-feedback-left" name ="username" placeholder="Username">
                  <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                </div>
              </div>
              <div class="item form-group">
                <div class="col-md-12 col-sm-12  form-group has-feedback">
                  <input name="password" type="password" class="form-control has-feedback-left" placeholder="Password">
                  <span class="fa fa-lock form-control-feedback left" aria-hidden="true"></span>
                </div>
              </div>
              <div class="ln_solid"></div>
              <div class="item form-group">
                <div class="col-md-12 col-sm-12">
                  <center>
                    <button type="submit" class="btn text-white" name="login" style="background-color: darkslategrey;">L O G I N</button>
                  </center>
                  <br>
                  <center>
                  <h4 style="color:seagreen">Don't have an acount yet?</h4><a href="register.php" style="color: seagreen; text-decoration:underline"><h4> Sign Up</h4></a>
                  </center>
                </div>
              </div>

              </form>
              </div>
            </div>
          </div>
        </div>
        </div>
  </body>
</html>
