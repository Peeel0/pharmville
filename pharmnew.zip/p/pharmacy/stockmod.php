<!DOCTYPE html>
<html lang="en">
<?php
session_start();
include 'include/header.php';
include 'include/dbconnection.php';
?>

  <body class="nav-md">
            <?php include 'include/sidebar.php';?>
            <?php include 'include/menufooter.php';?>
          </div>
        </div>

        <?php include 'include/topnav.php';?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3><i class="fa fa-file-prescription"></i> Medicine Stocks</h3>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <?php 
                if(isset($_GET['stockid'])){
                  $idd = $_GET['stockid'];
                  $sq = "SELECT * FROM medicines WHERE ID='$idd'";
                  $sqr = mysqli_query($con, $sq);
                  $ss = mysqli_fetch_assoc($sqr);

                  $name = $ss['med_name'];


                


                ?>


                <div class="x_panel">
                  <div class="x_title">
                    <h2><?php echo $name; ?></h2>
                    <ul class="nav navbar-right panel_toolbox">
                    <a class="btn btn-sm btn-info text-white" data-toggle ="modal" data-target="#addMeds"><i class="fa fa-plus"></i> Add Stock</a>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                  <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th>Stock #</th>
                          <th>Quantity</th>
                          <th style="margin-right: -10px">Expiration Date</th>
                          <th style="width: 15%">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        $x = 1;
                          $query="SELECT * FROM medicines_stock WHERE med_id='$idd';";
                          $sql = mysqli_query($con,$query);
                          while($row = mysqli_fetch_assoc($sql)){
                        ?>
                        <tr>
                          <td ><?php echo $x++;?></td>
                          <td><?php echo $row["QUANTITY"];?></td>
                          <td><?php echo $row["EXPIRY_DATE"];?></td>
                        
                          <td>
                          
                            <a data-toggle="modal" data-target="#decreasestock<?php echo $row["stock_id"]; ?>" id="decrease" class="btn btn-sm btn-danger text-white"><i class="fa-solid fa-minus"></i></a>
                        
                          </td>
                        </tr>


   <div class="modal fade" id="decreasestock<?php echo $row["stock_id"]; ?>"  aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Decrease Stocks</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="medback.php" method = "POST">
        <div class="modal-body">
            
              <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                 <label>Remaining stocks</label>
                <input type="number" class="form-control" name ="remain" value="<?php echo $row["QUANTITY"]; ?>" readonly>
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">

                <input type="number" class="form-control" name ="stocks" placeholder="Enter number to deduct">
                  <input type="hidden" class="form-control" name="medid" value="<?php echo $row["stock_id"]; ?>" placeholder="">
              </div>
            </div>
        
          
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" name ="reduce">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>
                        <?php
                        
                          }
                        ?>


                      </tbody>
                    </table>
                  </div>
                </div>
             
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="modal fade" id="addMeds"  aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Stock</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="medback.php" method = "POST">
        <div class="modal-body">
            
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="number" class="form-control" name ="stocks" placeholder="Stocks">
                  <input type="hidden" class="form-control" name="medid" value="<?php echo $idd; ?>" placeholder="">
              </div>
            </div>
        
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="date" class="form-control" name ="exp_date" placeholder="Expiration Date">
              </div>
            </div>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" name ="addstock">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>
 <?php }
              ?>
    <?php include 'include/footer.php';?>


  </body>
</html>
