<?php 
session_start();
include('include/header.php');
$lat = $_SESSION['lat'];
$lng = $_SESSION['lng'];

?>
<!DOCTYPE html >
  <head>
    <meta name="viewport" content="initial-scale=3.0, user-scalable=no" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
    <title>PharmVille - Map </title>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
      }
    </style>
  </head>

<html>
  <body class="nav-md">
  
    <div id="map"></div>
    <div class="container">
      
    <script>
      var customLabel = {
        restaurant: {
          label: ''
        },
        bar: {
          label: ''
        }
      };
        
        function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          center: {<?php echo'lat:'. $lat .', lng:'. $lng ;?>},
          zoom: 16
        });
        var infoWindow = new google.maps.InfoWindow;

          // Change this depending on the name of your PHP or XML file
          downloadUrl('xml.php', function(data) {
            var xml = data.responseXML;
            var markers = xml.documentElement.getElementsByTagName('marker');
            Array.prototype.forEach.call(markers, function(markerElem) {
              var id = markerElem.getAttribute('ID');
              var pname = markerElem.getAttribute('pname');
              var address = markerElem.getAttribute('address');

              var point = new google.maps.LatLng(
                  parseFloat(markerElem.getAttribute('lat')),
                  parseFloat(markerElem.getAttribute('lng')));

              var infowincontent = document.createElement('div');
              var strong = document.createElement('strong');
              strong.textContent = pname
              infowincontent.appendChild(strong);
              infowincontent.appendChild(document.createElement('br'));

              var text = document.createElement('text');
              text.textContent = address
              infowincontent.appendChild(text);
              var icon = customLabel[address] || {};
              var marker = new google.maps.Marker({
                map: map,
                position: point,
                icon: {
                      url: 'images/mark.png',
                      size: new google.maps.Size(70, 70),
                      scaledSize: new google.maps.Size(70, 70),
                      anchor: new google.maps.Point(0, 70)
                      }
                
              });

              infowincontent.appendChild(document.createElement('br'));
            

              marker.addListener('click', function() {
                infoWindow.setContent(infowincontent);
                infoWindow.open(map, marker);
              });
            });
          });
        }



      function downloadUrl(url, callback) {
        var request = window.ActiveXObject ?
            new ActiveXObject('Microsoft.XMLHTTP') :
            new XMLHttpRequest;

        request.onreadystatechange = function() {
          if (request.readyState == 4) {
            request.onreadystatechange = doNothing;
            callback(request, request.status);
          }
        };

        request.open('GET', url, true);
        request.send(null);
      }

      function doNothing() {}
    </script>

    <script
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBtS7FKa0Htep0uWLufFtDhMQCtB0I8VjI&callback=initMap&libraries=&v=weekly"
      defer
    ></script>
    </div>
  </body>
</html>