<?php
include ('header.php'); 

if (isset($_POST['upPharmacy']))
{
    $upID = $_POST['upID'];
    $uppname = $_POST['uppname'];
    $upowner = $_POST['upowner'];
    $upaddress = $_POST['upaddress'];
    $upcontact = $_POST['upcontact'];
    $upemail = $_POST['upemail'];

    $query = "UPDATE pharmacies SET
    pname = '$uppname', 
    owner = '$upowner',
    address = '$upaddress',
    contact = '$upcontact',
    email = '$upemail'

    WHERE ID = '$upID' ";

    $query_run = mysqli_query($con, $query);

    if ($query_run)
    {
        echo '<script type="text/javascript">
            swal({
            title: "Successfully Updated!",
            icon: "success",
            button: "Close",
            });
            setTimeout(function(){location.reload(1)},3000000);
        </script>';
    }
    else {
        echo("Error description: ". mysqli_error($con));
      }
}

else if (isset($_POST['upUser']))
{
    $upID = $_POST['upID'];
    $upfname = $_POST['upfname'];
    $uplname = $_POST['uplname'];
    $upusername = $_POST['upusername'];
    $uppassword = $_POST['uppassword'];
    $upemail = $_POST['upemail'];

    $query = "UPDATE users SET
    fname = '$upfname', 
    lname = '$uplname',
    username = '$upusername',
    password = '$uppassword',
    email = '$upemail'

    WHERE user_id = '$upID' ";

    $query_run = mysqli_query($con, $query);

    if ($query_run)
    {
        echo '<script type="text/javascript">
            swal({
            title: "Successfully Updated!",
            icon: "success",
            button: "Close",
            });
            setTimeout(function(){location.reload(1)},3000000);
        </script>';
    }
    else {
        echo("Error description: ". mysqli_error($con));
      }
}

?>

<script>
    $(function() {
        //Take the data from the TR during the event button
        $('table').on('click', 'a#editPharmacy', function (ele) {
            //the <tr> variable is use to set the parentNode from "ele
            var tr = ele.target.parentNode.parentNode;

            //I get the value from the cells (td) using the parentNode (var tr)
            var upID = tr.cells[0].textContent;
            var uppname = tr.cells[1].textContent;
            var upowner = tr.cells[2].textContent;
            var upaddress = tr.cells[3].textContent;
            var upcontact = tr.cells[4].textContent;
            var upemail = tr.cells[5].textContent;

            //Prefill the fields with the gathered information
            $('h5.modal-title').html('Edit Pharmacy ');
            $('#upID').val(upID);
            $('#uppname').val(uppname);
            $('#upowner').val(upowner);
            $('#upaddress').val(upaddress);
            $('#upcontact').val(upcontact);
            $('#upemail').val(upemail);

            //If you need to update the form data and change the button link
            $("form#upPharmModal").attr('action', window.location.href);
            $("button#upPharmacy").attr('href', window.location.href);
        });
        });

        $(function() {
        //Take the data from the TR during the event button
        $('table').on('click', 'a#editUsers', function (ele) {
            //the <tr> variable is use to set the parentNode from "ele
            var tr = ele.target.parentNode.parentNode;

            //I get the value from the cells (td) using the parentNode (var tr)
            var upID = tr.cells[0].textContent;
            var upfname = tr.cells[1].textContent;
            var uplname = tr.cells[2].textContent;
            var upusername = tr.cells[3].textContent;
            var uppassword = tr.cells[4].textContent;
            var upemail = tr.cells[5].textContent;

            //Prefill the fields with the gathered information
            $('h5.modal-title').html('Edit User ');
            $('#upID').val(upID);
            $('#upfname').val(upfname);
            $('#uplname').val(uplname);
            $('#upusername').val(upusername);
            $('#uppassword').val(uppassword);
            $('#upemail').val(upemail);

            //If you need to update the form data and change the button link
            $("form#upUserModal").attr('action', window.location.href);
            $("button#upUser").attr('href', window.location.href);
        });
        });
        
</script>
