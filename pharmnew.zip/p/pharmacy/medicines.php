<?php
session_start();
include 'include/header.php';
include 'include/dbconnection.php';
?>
 <?php
if(isset($_SESSION['title']) && $_SESSION['title'] !=''){
  
  ?>
  
  // swal("Good job!", "You clicked the button!", "success");
<?php 
    unset($_SESSION['title']);
  }
  ?>
  <!DOCTYPE html>
  <html lang="en">
  <body class="nav-md">
  <script>
    swal({
      title: "<?php echo $_SESSION['title']; ?>",
      icon: "<?php echo $_SESSION['icon']; ?>",
      button: "Close",
    });
    </script>
            <?php include 'include/sidebar.php';?>
            <?php include 'include/menufooter.php';?>
          </div>
        </div>

        <?php include 'include/topnav.php';?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="" >
            <div class="page-title">
              <div class="title_left">
                <h3><i class="fa fa-file-prescription"></i> Medicines</h3>
              </div>
            </div>

            <div class="clearfix" style="height:100px;"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12" style="height:400px; overflow:auto;">

                <div class="x_panel">
                  <div class="x_title">
                    <h2>List of Medicines</h2>
                    <ul class="nav navbar-right panel_toolbox">
                    <a class="btn btn-sm btn-info text-white" data-toggle ="modal" data-target="#addMeds"><i class="fa fa-plus"></i> Add Medicine</a>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                  <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th style="display: none">ID</th>
                          <th>Medicine Name</th>
                          <th style="margin-right: -10px">Quantity</th>
                          <th>Generic Name</th>
                          <th>Expiration Date</th>
                          <th style="width: 15%">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          $query="SELECT  m.ID, m.med_name, m.gen_name, s.EXPIRY_DATE, SUM(s.QUANTITY) AS qt
                            FROM medicines m 
                           INNER JOIN medicines_stock s 
                           ON m.ID=s.med_id
                           GROUP BY s.med_id;;";
                          $sql = mysqli_query($con,$query);
                          while($row = mysqli_fetch_assoc($sql)){
                        ?>
                        <tr>
                          <td style="display: none  "><?php echo $row["ID"];?></td>
                          <td><?php echo $row["med_name"];?></td>
                          <td><?php echo $row["qt"];?></td>
                          <td><?php echo $row["gen_name"];?></td>
                          <td><?php echo $row["EXPIRY_DATE"];?></td>
                          <td>
                            <a class="btn btn-sm btn-success text-white" data-toggle="modal" data-target="#editMed<?php echo $row["ID"];?>" id="editPharmacy"><i class="fa fa-edit"></i> </a>
                            <a class="btn btn-sm btn-danger text-white" data-toggle="modal" data-target="#delmodal<?php echo $row["ID"];?>" id="delmod"><i class="fa fa-trash"></i></a>
                            <?php //echo '<a href="medback.php?medi='.$row["ID"].'" class="btn btn-sm btn-danger text-white"><i class="fa fa-trash"></i></a>'; ?>
                           <?php echo '<a class="btn btn-sm btn-warning text-white" href="stockmod.php?stockid='.$row["ID"].'" id="editPharmacy"><i class="fa-solid fa-box"></i></a>' ?>
                          </td>
                        </tr>
<div class="modal fade" id="editMed<?php echo $row["ID"];?>"  aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Medicine</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="medback.php" method = "POST">
        <div class="modal-body">
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="med_name" placeholder="Medicine Name" value="<?php echo $row["med_name"];?>">
                <input type="hidden" class="form-control" name ="medid" placeholder="Medicine Name" value="<?php echo $row["ID"];?>">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12 form-group has-feedback">
                <input type="number" class="form-control" name ="stocks" placeholder="Stocks" value="<?php echo $row["qt"];?>" readonly>
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="gen_name" placeholder="Generic Name" value="<?php echo $row["gen_name"];?>" >
              </div>
            </div>
           
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" name ="editm">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="delmodal<?php echo $row["ID"];?>"  aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete Medicine</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="medback.php" method = "POST">
        <div class="modal-body align-center">
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
               <h2 style="text-align: center; color: black;">Are you sure you want to delete this medicine?</h2>
                <input type="hidden" class="form-control" name ="medi" placeholder="Medicine Name" value="<?php echo $row["ID"];?>">
              </div>
            </div>
             <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
               <p style="text-align: center; color: darkgrey;"><i>Please enter your password to confirm:</i></p>
                <input type="password" class="form-control" style="text-align: center;"  name ="pass" placeholder="Enter password">
              </div>
            </div>
          
           
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-danger" name ="delm">Delete</button>
      </div>
      </form>
    </div>
  </div>
</div>


                        <?php
                         // include 'stockmod.php';
                          }
                        ?>


                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  <div class="modal fade" id="addMeds"  aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Medicines</h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close">&times;</button>
      </div>
      <form action="medback.php" method = "POST">
        <div class="modal-body">
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="med_name" placeholder="Medicine Name">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="number" class="form-control" name ="stocks" placeholder="Stocks">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="gen_name" placeholder="Generic Name">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="date" class="form-control" name ="exp_date" placeholder="Expiration Date">
              </div>
            </div>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" name ="addm">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>

    <?php include 'include/footer.php';?>


  </body>
</html>
