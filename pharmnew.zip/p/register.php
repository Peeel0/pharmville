<?php
session_start();
include 'admin/include/dbconnection.php';  
include 'admin/include/header.php';     

    if (isset($_POST['register']))
     {
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
   
        $sql = "SELECT * FROM users WHERE username = '$username'";
        $result = mysqli_query($con, $sql);    
        
        if (!$result->num_rows > 0){
        $sql = "INSERT INTO `users`(`fname`, `lname`, `username`, `password`, `email`) VALUES ('$fname','$lname','$username','$password','$email')";

        $result = mysqli_query($con, $sql);
            if($result){
                echo '<script> alert("Done");</script>';
                  header('location: index.php');
            }
            else{
                echo '<script> alert("Failed");</script>';
            }
        }
            else{
              echo '<script> alert("Failed");</script>';

            }


   }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>PharmVille</title>

    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="vendors/animate.css/animate.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">

    <script>
      var x = document.getElementById("demo");

      function getLocation() {
      if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(showPosition);
      } else { 
      x.innerHTML = "Geolocation is not supported by this browser.";
      }
      }

      function showPosition(position) {
      var lat = position.coords.latitude;
      $("#lat".val(lat));
      var long = position.coords.longitude;
      x.innerHTML = "Latitude: " + position.coords.latitude;

      
      }
    </script>
  </head>

  <body class="login" onload="getLocation()">
      <div class="login_wrapper" style="margin-top: -1px">
        <div class="row">
          <div class="col-md-12 col-sm-12  ">
            <div class="x_panel">
              <div class="x_title">
                <center><img src="build/images/logo.png" alt="..." width="200"></center>
                <div class="clearfix"></div>
              </div>
              <div class="x_content">
              <form id="" method="POST" data-parsley-validate class="form-horizontal form-label-left">
                
                
              <div class="item form-group">
                <div class="col-md-12 col-sm-12  form-group has-feedback">
                  <input type="text" class="form-control has-feedback-left" name ="fname" placeholder="First Name">
                  <span class="fa-regular fa-id-badge form-control-feedback left" aria-hidden="true"></span>
                </div>
              </div>
              <div class="item form-group">
                <div class="col-md-12 col-sm-12  form-group has-feedback">
                  <input type="text" class="form-control has-feedback-left" name ="lname" placeholder="Last Name">
                  <span class="fa-solid fa-id-card form-control-feedback left" aria-hidden="true"></span>
                </div>
              </div>
              <div class="item form-group">
                <div class="col-md-12 col-sm-12  form-group has-feedback">
                  <input type="text" class="form-control has-feedback-left" name ="username" placeholder="Username">
                  <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                </div>
              </div>
              <div class="item form-group">
                <div class="col-md-12 col-sm-12  form-group has-feedback">
                  <input type="email" class="form-control has-feedback-left" name ="email" placeholder="Email">
                  <span class="fa fa-envelope form-control-feedback left" aria-hidden="true"></span>
                </div>
              </div>
              <div class="item form-group">
                <div class="col-md-12 col-sm-12  form-group has-feedback">
                  <input name="password" type="password" class="form-control has-feedback-left" placeholder="Password">
                  <span class="fa fa-lock form-control-feedback left" aria-hidden="true"></span>
                </div>
              </div>
              <div class="ln_solid"></div>
              <div class="item form-group">
                <div class="col-md-12 col-sm-12">
                  <center>
                    <button type="submit" class="btn" name="register" style="background-color: rgb(22, 104, 122);color: rgb(192, 202, 211);">R E G I S T E R</button>
                  </center>
                </div>
              </div>

              </form>
              </div>
            </div>
          </div>
        </div>
        </div>
  </body>
</html>
