<style>
  .bg{
    background-color: #478C5C !important;
  }
</style>

<div class="container body bg" >
      <div class="main_container bg">
        <div class="col-md-3 left_col bg" >
          <div class="left_col scroll-view bg">
            <div class="navbar nav_title bg">
            </div>
            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile clearfix" >
              <div class="profile_pic">
              <center><img src="../build/images/logo2.png" alt="..." width="150" style="margin-top:-5px; margin-left: 35px"></center>
              </div>
            </div>
            <!-- /menu profile quick info -->
            <br />
            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <ul class="nav side-menu">
                <li><a href="pharmacies.php"><i class="fa fa-hand-holding-medical"></i> Pharmacies</a></li>
                <!--<li><a href="medicines.php"><i class="fa fa-file-prescription"></i> Medicines</a></li>-->
                <li><a href="map.php"><i class="fa fa-map-location"></i> Map</a></li>
                </ul>
              </div>

            </div>
            <!-- /sidebar menu -->