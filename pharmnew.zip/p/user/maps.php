	<?php
	session_start();
	/* Database connection settings */
	$host = 'localhost';
	$user = 'root';
	$pass = '';
	$db = 'pharmacy';
	$mysqli = new mysqli($host,$user,$pass,$db) or die($mysqli->error);

	// $lat = $_GET['lat'];
	// $lng = $_GET['lng'];
	// $userlat = $_SESSION['lat'];
	// $userlng = $_SESSION['lng'];
	$name = $_GET['name'];

 	$coordinates = array();
 	$latitudes = array();
 	$longitudes = array();

	// Select all the rows in the markers table
	$query = "SELECT  `locationLatitude`, `locationLongitude` FROM `location_tab` ";
	$result = $mysqli->query($query) or die('data selection for google map failed: ' . $mysqli->error);

 	while ($row = mysqli_fetch_array($result)) {

		$latitudes[] = $row['locationLatitude'];
		$longitudes[] = $row['locationLongitude'];
		$coordinates[] = 'new google.maps.LatLng(' . $row['locationLatitude'] .','. $row['locationLongitude'] .'),';
	}

	//remove the comaa ',' from last coordinate
	$lastcount = count($coordinates)-1;
	$coordinates[$lastcount] = trim($coordinates[$lastcount]);	
?>

<!DOCTYPE html>
<html>
	<head>
    	<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="styl.css">
		<title>Map | View</title>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	</head>

	<body>

		 <div class="outer-scontainer">
		<div id="map" style="width: 100%; height: 100vh;"></div>
		<input type="hidden" class="locations" value="<?=$_GET['end']?>" id="start" name="">
		<input type="hidden" value="<?=$_GET['name']?>" id="end" name="">
		<script>
			function initMap() {
	        var directionsService = new google.maps.DirectionsService;
	        var directionsDisplay = new google.maps.DirectionsRenderer;
	        var geocoder = new google.maps.Geocoder;
	        var map = new google.maps.Map(document.getElementById('map'), {
	          zoom: 5,
	          center: {lat: 14.068901, lng: 120.628619}
	        });
	        directionsDisplay.setMap(map);
	        calculateAndDisplayRoute(directionsService,directionsDisplay);
	      }
	      function calculateAndDisplayRoute(directionsService,directionsDisplay) {
	        directionsService.route({
	          origin: document.getElementById('start').value,
	          destination: document.getElementById('end').value,
	          travelMode: 'DRIVING'
	        }, function(response, status) {
	          if (status === 'OK') {
	            directionsDisplay.setDirections(response);
	          } else {
	            window.alert('Directions request failed due to ' + status);
	          }
	        });
	      }

	      navigator.geolocation
	      navigator.geolocation.getCurrentPosition(console.log, console.log)
	      const sucessfulLookup=(position) => {
		    const {latitude, longitude} = position.coords;
		    fetch(`https://api.opencagedata.com/geocode/v1/json?q=${latitude}+${longitude}&key=c89c9d1e30ce4785ba46aebd406ce1e0`)
		    .then(response => response.json())
		    .then(console.log)
		};
		navigator.geolocation.getCurrentPosition(sucessfulLookup, console.log)
    	</script>
		

    	<!--remenber to put your google map key-->
	    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBtS7FKa0Htep0uWLufFtDhMQCtB0I8VjI&callback=initMap&libraries=&v=weekly"></script>

	</body>
</html>