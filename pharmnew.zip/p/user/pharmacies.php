<!DOCTYPE html>
<html lang="en">
<?php
include 'include/header.php';
include 'include/dbconnection.php';

if (isset($_POST['addPharm']))
{
  $pname = $_POST['pname'];
  $owner = $_POST['owner'];
  $address = $_POST['address'];
  $contact = $_POST['contact'];
  $email = $_POST['email'];
  
  $sql = "INSERT INTO `pharmacies`(`pname`, `owner`, `address`, `contact`, `email`) VALUES ('$pname','$owner','$address','$contact','$email')";
  $result = mysqli_query($con, $sql);

  if($result)
  {
    echo '<script> alert("Pharmacy Succesfully Added");</script>';
  
  }
  else {
    echo("Error description: ". mysqli_error($con));
  }
}

else if (isset($_GET['id']))
{
  $id = $_GET['id'];

    $query = "DELETE FROM pharmacies WHERE ID = '$id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
      echo '<script type="text/javascript">
          swal({
          title: "Successfully Deleted!",
          icon: "success",
          button: "Close",
          });
          setTimeout(function(){location.reload(1)},3000000);
      </script>';

    }
    else {
      echo '<script type="text/javascript">
          swal({
          title: "Delete Failed!",
          icon: "success",
          button: "Close",
          });
          setTimeout(function(){location.reload(1)},3000000);
      </script>';
    }
}

else if(isset($_POST['searchPharm']))
{
  $search = $_POST['search'];

  echo("<script>location.href='filter_pharm.php?med=$search'</script>");  
}
?>




  <body class="nav-md">
            <?php include 'include/sidebar.php';?>
            <?php include 'include/menufooter.php';?>
          </div>
        </div>

        <?php include 'include/topnav.php';?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            

        <!-- Topbar Search -->
            

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <ul class="nav navbar-right panel_toolbox">
                      <form method="POST" style="margin-left:">
                        <div class="input-group">
                            <input type="text" name="search" class="form-control bg-light border-1 small" placeholder="Search for..."
                                aria-label="Search" aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-info" type="submit" name="searchPharm">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                      </form>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                          <?php
                            $query="SELECT * FROM pharmacies";
                            $sql = mysqli_query($con,$query);
                            while($row = mysqli_fetch_array($sql)){
                          ?>
                        <a href="maps.php?name=<?=$row['address']?>&end=<?=$_COOKIE['locname']?>">
                          <div class="col">
                            <div class="card" style="width: 18rem;">
                              <img src="images/pharm.jpg" class="card-img-top" alt="...">
                              <div class="card-body">
                                <h5 class="card-title"><?php echo $row["pname"];?></h5>
                                <p class="card-text"><?php echo $row["address"];?></p>
                                <div style="display: none"><?php echo $row["lat"];?></div>
                                <div  style="display: none"><?php echo $row["lng"];?></div>
                              </div>
                            </div>
                          </div>
                        </a>
                          <?php
                            }
                          ?>
                      </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<div class="modal fade" id="editPharm" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Pharmacy</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="" method = "POST" id="upPharmModal">
        <div class="modal-body">
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
              <input type="hidden" class="form-control" name ="upID" id="upID">

                <input type="text" class="form-control" name ="uppname" id="uppname" placeholder="">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="upowner" id="upowner" placeholder="">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="upaddress" id="upaddress" placeholder="">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="upcontact" id="upcontact" placeholder="">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="upemail" id="upemail" placeholder="">
              </div>
            </div>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" name ="upPharmacy" id="upPharmacy">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="addPharm" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Pharmacy</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="" method = "POST">
        <div class="modal-body">
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="pname" placeholder="Pharmacy Name">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="owner" placeholder="Name of Owner">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="address" placeholder="Address">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="contact" placeholder="Contact Number">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="email" placeholder="Email Address">
              </div>
            </div>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" name ="addPharm">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>
    <?php include 'include/footer.php';?>
  </body>
  <script>
			var $locationText = $(".location");

// Check for geolocation browser support and execute success method
if (navigator.geolocation) {
  navigator.geolocation.getCurrentPosition(
    geoLocationSuccess,
    geoLocationError,
    { timeout: 10000 }
  );
} else {
  alert("your browser doesn't support geolocation");
}
function geoLocationSuccess(pos) {
  // get user lat,long
  var myLat = pos.coords.latitude,
    myLng = pos.coords.longitude,
    loadingTimeout;

  var loading = function () {
    $locationText.text("fetching...");
  };

  loadingTimeout = setTimeout(loading, 600);

  var request = $.get(
    "https://nominatim.openstreetmap.org/reverse?format=json&lat=" +
      myLat +
      "&lon=" +
      myLng
  )
    .done(function (data) {
      if (loadingTimeout) {
        clearTimeout(loadingTimeout);
        loadingTimeout = null;
        $locationText.val(data.display_name);
        var loc = data.display_name;document.cookie="locname="+loc;
      }
    })
    .fail(function () {
      // handle error
    });
}

function geoLocationError(error) {
  var errors = {
    1: "Permission denied",
    2: "Position unavailable",
    3: "Request timeout"
  };
  alert("Error: " + errors[error.code]);
}

		</script>
    <script>
var address = "";
var latitude = "";
var longitude = "";
var zoom_out = "";
var is_converter = "";
var myLocationLat = "";
var myLocationLng = "";
var isMapOn = "";
var countMap = 0;
var countConvert = 0;
var countConvertLimit = 20;
var is_county = "";
var token = "";
var is_zip = "";
var is_city = "";
var is_state = "";
var is_country = "";
var country = "";
var map;

 if(isEmpty(address))
 {	 
    if(isEmpty(myLocationLat))
	{
		if (!navigator.geolocation) {
		} else {
			navigator.geolocation.getCurrentPosition(showLocation); 
		}
	} else {

		document.getElementById('latitude').value = myLocationLat;
		document.getElementById('longitude').value = myLocationLng;
		getAddressByCoordinates();
	}
 } else {
		document.getElementById('latitude').value = myLocationLat;
		document.getElementById('longitude').value = myLocationLng;
		getAddressByCoordinates();
		document.getElementById('address').innerHTML = address;	
 }
function addPop(lat, lng){
	document.getElementById('latitude').innerHTML = lat;
	document.getElementById('longitude').innerHTML = lng;
	
	var url = "https://my-location.org/?lat="+lat+"&lng="+lng;
				
			document.getElementById('my_location').value = url;
		document.getElementById('coordinates_url').value = "<a href=\""+url+"\" target=\"_blank\">("+lat+","+lng+")</a>";
		var latDms = getDD2DMS(lat,"lat");
	var lngDms = getDD2DMS(lng,"lng");
				
	var latDegrees = latDms[0];
	var latMinutes = latDms[1];
	var latSeconds = latDms[2];
	var latDirection = latDms[3];
				
	var lngDegrees = lngDms[0];
	var lngMinutes = lngDms[1];
	var lngSeconds = lngDms[2];
	var lngDirection = lngDms[3];
				
	document.getElementById('latitude_dms_degrees').innerHTML = latDegrees;
	document.getElementById('latitude_dms_minutes').innerHTML = latMinutes;
	document.getElementById('latitude_dms_seconds').innerHTML = latSeconds;
	
	document.getElementById('latitude_dms_ns').innerHTML = latDirection;
	document.getElementById('longitude_dms_degrees').innerHTML = lngDegrees;
	document.getElementById('longitude_dms_minutes').innerHTML = lngMinutes;
	document.getElementById('longitude_dms_seconds').innerHTML = lngSeconds;
	document.getElementById('longitude_dms_ew').innerHTML = lngDirection;
}
			
function showMapByCoordinates(err, data) {
	var formattedAddress = data.results[0].formattedAddress;
	document.getElementById('address').innerHTML = formattedAddress;

	var countryCode = data.results[0].countryCode;

	if(countryCode == "US")
	{		
		var res = formattedAddress.split(",");
		var country = "United States";		
		var arrayLength = res.length;
		var stateZip = res[arrayLength-2];
		var stateZipArray = stateZip.split("  ");
		var zip = stateZipArray[1];
		var state = stateZipArray[0];
		
		if(!isEmpty(is_county)){
			 document.getElementById('county_div').style.visibility = 'visible'; 
			 getCounty(zip);
		}
		if(!isEmpty(is_zip)){
			 document.getElementById('zip_div').style.visibility = 'visible';

			 document.getElementById("zip").innerHTML = zip;
		}
		if(!isEmpty(is_city)){
			 document.getElementById('city_div').style.visibility = 'visible';
			 document.getElementById("city").innerHTML = res[arrayLength-3];
		}
		if(!isEmpty(is_state)){
			 document.getElementById('state_div').style.visibility = 'visible';
			 var stateZip = res[arrayLength-2];
			 var stateZipArray = stateZip.split("  ");
			 document.getElementById("state").innerHTML = stateLookup(state);
		}	
		if(!isEmpty(is_country)){
			 document.getElementById('country_div').style.visibility = 'visible';
			 document.getElementById("country").innerHTML = country;
		}
	}
}

function getAddressByCoordinates(){
	var latitude = parseFloat(document.getElementById('latitude').value);
	var longitude = parseFloat(document.getElementById('longitude').value);
	setMap(latitude, longitude);
}

function setMap(latitude, longitude){

		var img = document.getElementById('default_map');
		img.style.visibility = 'hidden';
		
		map = new mapkit.Map('map', {showsMapTypeControl: false,showsCompass: mapkit.FeatureVisibility.Hidden});
		centerMap(latitude, longitude);
		if(isEmpty(address)){		///lookup address if address is not predefine
			reverseQuery(latitude, longitude);
		}
		addPop(latitude, longitude);
}

 function showLocation(position) { 
	setMap(position.coords.latitude, position.coords.longitude);
 }
 
 function centerMap(latitude, longitude){
	const coordinates = new mapkit.Coordinate(latitude, longitude);
	const annotation = new mapkit.MarkerAnnotation(coordinates, {
			   data: { },
			   color: 'red'
	})
	map.addAnnotation(annotation);	
	
	var coordinateRegion = new mapkit.CoordinateRegion(
		new mapkit.Coordinate(latitude, longitude),
		new mapkit.CoordinateSpan(0.0100, 0.0100)
	);
	map.region = coordinateRegion;
 }
 
 function reverseQuery(latitude, longitude){
	var geocoder = new mapkit.Geocoder({
		language: "en-GB",
		getsUserLocation: true
	}).reverseLookup(new mapkit.Coordinate(latitude, longitude), (err, data) => {
		showMapByCoordinates(err, data);			
	});
 }
</script>
</html>

<?php
include 'include/script.php';
?>