<?php
require("include/dbconnection.php");

function parseToXML($htmlStr)
{
$xmlStr=str_replace('<','&lt;',$htmlStr);
$xmlStr=str_replace('>','&gt;',$xmlStr);
$xmlStr=str_replace('"','&quot;',$xmlStr);
$xmlStr=str_replace("'",'&#39;',$xmlStr);
$xmlStr=str_replace("&",'&amp;',$xmlStr);
return $xmlStr;
}

$med = $_GET['med'];
if ($med != ''){
  $query = "SELECT * FROM pharmacies t1 inner join medicines t2 on t1.ID = t2.pharm_id where t2.med_name LIKE '%$med%' or t2.gen_name LIKE '%$med%' or t1.pname LIKE '%$med%' GROUP BY t1.pname";
  $result = mysqli_query($con,$query);
  if (!$result) {
    die('Invalid query: ' . mysqli_error());
  }

  header("Content-type: text/xml");

  // Start XML file, echo parent node
  echo "<?xml version='1.0' ?>";
  echo '<markers>';
  $ind=0;
  // Iterate through the rows, printing XML nodes for each
  while ($row = @mysqli_fetch_assoc($result)){
    // Add to XML document node
    echo '<marker ';
    echo 'ID="' . $row['ID'] . '" ';
    echo 'pname="' . parseToXML($row['pname']) . '" ';
    echo 'address="' . parseToXML($row['address']) . '" ';
    echo 'lat="' . $row['lat'] . '" ';
    echo 'lng="' . $row['lng'] . '" ';
    echo '/>';
    $ind = $ind + 1;
  }

  // End XML file
  echo '</markers>';
}else{
  $query = "";
  $result = mysqli_query($con,$query);
  if (!$result) {
    die('Invalid query: ' . mysqli_error());
  }

  header("Content-type: text/xml");

  // Start XML file, echo parent node
  echo "<?xml version='1.0' ?>";
  echo '<markers>';
  $ind=0;
  // Iterate through the rows, printing XML nodes for each
  while ($row = @mysqli_fetch_assoc($result)){
    // Add to XML document node
    echo '<marker ';
    echo 'ID="' . $row['ID'] . '" ';
    echo 'pname="' . parseToXML($row['pname']) . '" ';
    echo 'address="' . parseToXML($row['address']) . '" ';
    echo 'lat="' . $row['lat'] . '" ';
    echo 'lng="' . $row['lng'] . '" ';
    echo '/>';
    $ind = $ind + 1;
  }

  // End XML file
  echo '</markers>';
}

?>
