<!DOCTYPE html>
<html lang="en">
<?php
include 'include/header.php';
include 'include/dbconnection.php';

$med = $_GET['med'];

if(isset($_POST['searchPharm']))
{
  $search = $_POST['search'];

  echo("<script>location.href='filter_pharm.php?med=$search'</script>");  
}
?>




  <body class="nav-md">
            <?php include 'include/sidebar.php';?>
            <?php include 'include/menufooter.php';?>
          </div>
        </div>

        <?php include 'include/topnav.php';?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            

        <!-- Topbar Search -->
            

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <ul class="nav navbar-right panel_toolbox">
                      <form method="POST" style="margin-left:">
                        <div class="input-group">
                            <input type="text" name="search" class="form-control bg-light border-1 small" placeholder="Search for..."
                                aria-label="Search" aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-info" type="submit" name="searchPharm">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                      </form>
                    </ul>
                    <a href="pharmacies.php">All Pharmacies</a>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p>List of Pharmacies base   on your search</p>
                      <div class="row">
                          <?php
                            $query="SELECT medicines.med_name, medicines.gen_name, pharmacies.pname, pharmacies.address, pharmacies.lat, pharmacies.lng
                            FROM `medicines`
                            LEFT JOIN pharmacies
                            ON pharmacies.ID = medicines.pharm_id
                            WHERE medicines.med_name LIKE '%$med%' OR medicines.gen_name LIKE '%$med%' OR pharmacies.pname LIKE '%$med%' GROUP BY pharmacies.pname";
                            $sql = mysqli_query($con,$query);

                            if ($sql->num_rows > 0){
                              while($row = mysqli_fetch_array($sql)){
                          ?>
                          <a href="maps.php?name=<?=$row['address']?>'&end=<?=$_COOKIE['locname']?>'">
                            <div class="col my-2">
                              <div class="card" style="width: 18rem;">
                                <img src="images/pharm.jpg" class="card-img-top" alt="...">
                                <div class="card-body">
                                  <h5 class="card-title"><?php echo $row["pname"];?></h5>
                                  <p class="card-text"><?php echo $row["address"];?></p>
                                  <div style="display: none"><?php echo $row["lat"];?></div>
                                  <div  style="display: none"><?php echo $row["lng"];?></div>
                                </div>
                              </div>
                            </div>
                          </a>
                          <?php
                            }
                          }
                          ?>
                      </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<div class="modal fade" id="editPharm" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Pharmacy</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="" method = "POST" id="upPharmModal">
        <div class="modal-body">
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
              <input type="hidden" class="form-control" name ="upID" id="upID">

                <input type="text" class="form-control" name ="uppname" id="uppname" placeholder="">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="upowner" id="upowner" placeholder="">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="upaddress" id="upaddress" placeholder="">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="upcontact" id="upcontact" placeholder="">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="upemail" id="upemail" placeholder="">
              </div>
            </div>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" name ="upPharmacy" id="upPharmacy">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="addPharm" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Pharmacy</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="" method = "POST">
        <div class="modal-body">
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="pname" placeholder="Pharmacy Name">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="owner" placeholder="Name of Owner">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="address" placeholder="Address">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="contact" placeholder="Contact Number">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="email" placeholder="Email Address">
              </div>
            </div>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" name ="addPharm">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>
    <?php include 'include/footer.php';?>
  </body>
</html>
<?php
include 'include/script.php';
?>
<script>
			var $locationText = $(".location");

// Check for geolocation browser support and execute success method
if (navigator.geolocation) {
  navigator.geolocation.getCurrentPosition(
    geoLocationSuccess,
    geoLocationError,
    { timeout: 10000 }
  );
} else {
  alert("your browser doesn't support geolocation");
}
function geoLocationSuccess(pos) {
  // get user lat,long
  var myLat = pos.coords.latitude,
    myLng = pos.coords.longitude,
    loadingTimeout;

  var loading = function () {
    $locationText.text("fetching...");
  };

  loadingTimeout = setTimeout(loading, 600);

  var request = $.get(
    "https://nominatim.openstreetmap.org/reverse?format=json&lat=" +
      myLat +
      "&lon=" +
      myLng
  )
    .done(function (data) {
      if (loadingTimeout) {
        clearTimeout(loadingTimeout);
        loadingTimeout = null;
        $locationText.val(data.display_name);
        var loc = data.display_name;document.cookie="locname="+loc;
      }
    })
    .fail(function () {
      // handle error
    });
}

function geoLocationError(error) {
  var errors = {
    1: "Permission denied",
    2: "Position unavailable",
    3: "Request timeout"
  };
  alert("Error: " + errors[error.code]);
}

		</script>