<!DOCTYPE html>
<html lang="en">
<?php
session_start();
$userlat = $_SESSION['fname'];
include 'include/header.php';?>

  <body class="nav-md">
            <?php include 'include/sidebar.php';?>
          </div>
        </div>
        <?php include 'include/topnav.php';?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3><i class="fa fa-dashboard"></i><?php echo  $_SESSION['fname']?></h3>
              </div>
            </div>

            <div class="clearfix"></div>

            <h1> <?php echo $_SESSION['lat'];?> </h1>
              
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <?php include 'include/footer.php';?>
  </body>
</html>
