<!DOCTYPE html>
<html lang="en">
<?php 
session_start();
include 'include/header.php';
?>
<head>
<link href="build/css/style.css" rel="stylesheet">
<link href="build/css/custom.min.css" rel="stylesheet">
</head>
  <body class="nav-md">
            <?php include 'include/sidebar.php';?>
            <?php include 'include/menufooter.php';?>
          </div>
        </div>
        <?php include 'include/topnav.php';
      
        ?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left" style="color: #000; ">
                <h3><i class="fa fa-dashboard"></i> <?php
                 $pn = $_SESSION['pharmname'];
                  echo $pn;?></strong> Dashboard</h3>
              </div>
            </div>

            <div class="clearfix"></div>
            <div class="row">
                      <div class="col-md-12 col-sm-12" style="height:560px; overflow:auto;">
                        <div class="x_panel">
                        <div class="row">
                            <div class="col-md-4">
                            <div class="card" style="border-radius: 20%; width:250px;">
                            <img class="card-img-top " src="images/1.jpg" alt="Card image">
                              <div class="card-body card-img-overlay ">
                                <h5 style="color: white" >Total Medicines</h5>
                                <h1 style="color: white; font-size: 60px">
                                <?php
                                  $pp = $_SESSION['ppd'];
                                  $pid = "SELECT COUNT(pharm_id) AS cnt FROM medicines WHERE pharm_id = '$pp'";
                                  $resultq = mysqli_query($con, $pid);
                                  $row2=mysqli_fetch_assoc($resultq);
                                  $medcnt = $row2['cnt'];
                                  echo $medcnt;
                                  ?></h1>
                              </div>
                            </div>
                          </div>
                  <!-- <div class="col-md-4 ">
                    <div class="card " style="border-radius: 20%">
                    <img class="card-img-top " src="images/2.jpg" alt="Card image">
                      <div class="card-body card-img-overlay ">
                        <h5 style="color: white" >Total Pharmacies</h5>
                        <h1 style="color: white; font-size: 60px">
                        <?php
                            // $usid = "SELECT COUNT(ID) AS ucnt FROM pharmacies";
                            //  $usrcnt = mysqli_query($con, $usid);
                            //  $row3=mysqli_fetch_assoc($usrcnt);
                            //  $uscnt2 = $row3['ucnt'];
                            //  echo $uscnt2;
                          ?>
                          </h1>
                      </div>
                    </div>
                  </div> -->
                      <div class="col-md-4">
                      <div class="card " style="border-radius: 20%;  width:250px;">
                        <img class="card-img-top " src="images/3.jpg" alt="Card image">
                          <div class="card-body card-img-overlay ">
                            <h5 style="color: white" >Total Users</h5>
                            <h1 style="color: white; font-size: 60px"> <?php
                                $usid = "SELECT COUNT(user_id) AS ucnt FROM users";
                                $usrcnt = mysqli_query($con, $usid);
                                $row3=mysqli_fetch_assoc($usrcnt);
                                $uscnt = $row3['ucnt'];
                                echo $uscnt;
                              ?></h1>
                          </div>
                        </div>

                        
                </div>
                <div class="col-md-4">
                      <div class="card " style="border-radius: 20%;  width:250px;">
                        <img class="card-img-top " src="images/3.jpg" alt="Card image">
                          <div class="card-body card-img-overlay ">
                            <h5 style="color: white" >Low Stock Medicine</h5>
                            <h1 style="color: white; font-size: 60px"> <?php
                                $usid = "SELECT COUNT(medicines.ID) AS med FROM medicines
                                INNER JOIN medicines_stock
                                ON medicines.ID = medicines_stock.med_id
                                WHERE medicines_stock.QUANTITY <= 100";
                                $usrcnt = mysqli_query($con, $usid);
                                $row3=mysqli_fetch_assoc($usrcnt);
                                $uscnt = $row3['med'];
                                echo $uscnt;
                              ?></h1>
                          </div>
                        </div>  
</div>
              
                  <div class="x_content">
                  </div>
                
                  <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                    <h2 class="text-center" style="color: #000;font-weight: bold;">TOP 5 MOST SEARCH MEDICINE</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                  <table class="table table-bordered table-hover text-center" style="width:100%">
                      <thead class="text-center" style="background-image: url(images/3.jpg);">
                        <tr>
                          <th>Item Name</th>
                          <th>Quantity</th>
                          <th>Price</th>
                         
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Biogesic</td>
                          <td>30</td>
                          <td>Php7.00</td>
                        </tr>
                        <tr>
                          <td>Alaxan</td>
                          <td>20</td>
                          <td>Php10.00</td>  
                        </tr>
                        <tr>
                          <td>Tuseran</td>
                          <td>50</td>
                          <td>Php8.00</td>                         
                        </tr>
                        <tr>
                          <td>BioFlu</td>
                          <td>45</td>
                          <td>Php12.00</td>
                         
                        </tr>
                        <tr>
                          <td>Enervon</td>
                          <td>100</td>
                          <td>Php6.00</td>
                          
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <?php include 'include/footer.php';?>
  </body>
</html>
