<?php
session_start();
include 'include/dbconnection.php';

if(isset($_POST['addm'])){
	$name = $_POST['med_name'];
	$stocks=$_POST['stocks'];
	$exp = $_POST['exp_date'];
	$gen = $_POST['gen_name'];

 	$pid = $_SESSION['uid'];

 	//for inserting into medicine table
	$sql = "INSERT INTO medicines(pharm_id, med_name,gen_name) VALUES('$pid','$name','$gen')";
  	$result = mysqli_query($con, $sql);

  	//for fetching the recent id of medicine

  	$get = "SELECT ID FROM medicines ORDER BY ID DESC LIMIT 1";
  	$getr = mysqli_query($con, $get);
  	$x = mysqli_fetch_assoc($getr);
  	$idd = $x['ID'];
  	

  	//insert in stocks table
	$sql2 = "INSERT INTO medicines_stock(EXPIRY_DATE, QUANTITY,med_id) VALUES('$exp','$stocks','$idd')";
  	$result2 = mysqli_query($con, $sql2);

  	  header('location: medicines.php');



}

if(isset($_POST['addstock'])){
	$stocks=$_POST['stocks'];
	$exp = $_POST['exp_date'];

 	$sid = $_POST['medid'];

 
  	

  	//insert in stocks table
	$sql2 = "INSERT INTO medicines_stock(EXPIRY_DATE, QUANTITY,med_id) VALUES('$exp','$stocks','$sid')";
  	$result2 = mysqli_query($con, $sql2);

  	  header('location: medicines.php');
  	  //insert notification success



}

if(isset($_POST['reduce'])){
	$stocks=$_POST['stocks'];
	$rem=$_POST['remain'];

 	$sid = $_POST['medid'];

 	$ttl = 0;
 	$stocks = intval($stocks);
 	$rem = intval($rem);
 	$ttl = $rem-$stocks;

 	echo $ttl;





  	//insert in stocks table
	$sql2 = "UPDATE medicines_stock SET QUANTITY='$ttl' WHERE stock_id='$sid'";
  	$result2 = mysqli_query($con, $sql2);

  	  header('location: medicines.php');
  	  //insert notification success



}

if(isset($_POST['editm'])){
	$gen_name=$_POST['gen_name'];
	$med_name=$_POST['med_name'];

 	$mid = $_POST['medid'];




  	//insert in stocks table
	$sql2 = "UPDATE medicines SET med_name='$med_name', gen_name='$gen_name' WHERE ID='$mid' ";
  	$result2 = mysqli_query($con, $sql2);

  	  header('location: medicines.php');
  	  //insert notification success



}

if(isset($_POST['delm'])){

	$idd=$_POST['medi'];
	$pass = $_POST['pass'];
	$pp = $_SESSION['userid'];


$ss = "SELECT password FROM pharm_user WHERE ph_id='$pp' && password = '$pass'";
$sr = mysqli_query($con, $ss);
$y = mysqli_num_rows($sr);


if($y>0){

	$sql1 = "DELETE FROM medicines_stock WHERE med_id='$idd'";
  	$result1 = mysqli_query($con, $sql1);

  
	$sql2 = "DELETE FROM medicines WHERE ID='$idd'";
  	$result2 = mysqli_query($con, $sql2);


	 $_SESSION['title'] = "Successfully deleted!";
	 $_SESSION['icon'] = "success";
 header('location: medicines.php');
  	
}
else{
	echo $y;
	 
	 $_SESSION['title'] = "Incorrect password!";
	 $_SESSION['icon'] = "error";
//header('location: medicines.php');

}




}

 ?>