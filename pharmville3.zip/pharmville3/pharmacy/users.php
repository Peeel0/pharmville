<!DOCTYPE html>
<html lang="en">
<?php 
include 'include/header.php';
include 'include/dbconnection.php';

if (isset($_GET['id']))
{
  $id = $_GET['id'];

    $query = "DELETE FROM users WHERE user_id = '$id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
      echo '<script type="text/javascript">
              swal({
              title: "Successfully Deleted!",
              icon: "success",
              button: "Close",
              });
              setTimeout(function(){location.reload(1)},3000000);
            </script>';

    }
    else {
      echo '<script type="text/javascript">
              swal({
              title: "Delete Failed!",
              icon: "success",
              button: "Close",
              });
              setTimeout(function(){location.reload(1)},3000000);
            </script>';
    }
}

?>

  <body class="nav-md">
            <?php include 'include/sidebar.php';?>
            <?php include 'include/menufooter.php';?>
          </div>
        </div>

        <?php include 'include/topnav.php';?>

        <!-- page content -->
        <div class="right_col" role="main"   style="height: 200px;">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3><i class="fa fa-user"></i> Users</h3>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <ul class="nav navbar-right panel_toolbox">
                   <!-- <a href="add-cashier.php" class="btn btn-sm btn-info text-white"><i class="fa fa-user-plus"></i> Add Cashier</a> -->
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content" >
                  <table id="datatable" class="table table-striped table-bordered" style="width:100%; text-align: center">
                      <thead>
                        <tr>
                          <th style="display:none">ID</th>
                          <th>First Name</th>
                          <th>Last Name</th>
                          <th>Userame</th>
                          <th>Password</th>
                          <th>Email</th>
                          <th style="width: 11%">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          $query="SELECT * FROM users";
                          $sql = mysqli_query($con,$query);
                          while($row = mysqli_fetch_array($sql)){
                        ?>
                        <tr>
                          <td style="display: none  "><?php echo $row["user_id"];?></td>
                          <td><?php echo $row["fname"];?></td>
                          <td><?php echo $row["lname"];?></td>
                          <td><?php echo $row["username"];?></td>
                          <td><?php echo $row["password"];?></td>
                          <td><?php echo $row["email"];?></td>

                          <td>
                            <a class="btn btn-sm btn-success text-white" data-toggle="modal" data-target="#editUserModal" id="editUsers"><i class="fa fa-edit"></i> </a>
                            <a href="users.php?id=<?php echo $row["user_id"];?>" class="btn btn-sm btn-danger text-white"><i class="fa fa-trash"></i> </a>
                          </td>
                        </tr>
                        <?php
                          }
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="modal fade" id="editUserModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Users</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="" method = "POST" id="upUserModal">
        <div class="modal-body">
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
              <input type="hidden" class="form-control" name ="upID" id="upID">

                <input type="text" class="form-control" name ="upfname" id="upfname" placeholder="">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="uplname" id="uplname" placeholder="">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="upusername" id="upusername" placeholder="">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="uppassword" id="uppassword" placeholder="">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="upemail" id="upemail" placeholder="">
              </div>
            </div>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" name ="upUser" id="upUser">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>
    <?php
    include 'include/footer.php';
    include 'include/script.php';
    ?>
  
  </body>
</html>
