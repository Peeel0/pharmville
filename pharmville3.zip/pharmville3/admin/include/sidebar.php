<?php
//include 'include/header.php';
include 'include/dbconnection.php';
?>


<style>
.bg{
  background-color: #478C5C !important;

}
.nav-md ul.nav.child_menu li:after {
  border-left: 1px solid #425668;
  bottom: 0;
  content: "";
  left: 27px;
  position: absolute;
  top: 0; }

.nav-md ul.nav.child_menu li:last-child::after {
  bottom: 50%; }

.nav.side-menu > li > a, .nav.child_menu > li > a {
  color: #000 !important;
  font-weight: bolder; }

.nav.child_menu li li:hover,
.nav.child_menu li li.active {
  background: none; }

.nav.child_menu li li a:hover,
.nav.child_menu li li a.active {
  color: #fff;
 }

.nav > li > a {
  position: relative;
  display: block;
  padding: 13px 15px 12px; }

.nav.side-menu > li.current-page, .nav.side-menu > li.active {
  border-right: 5px solid #031d44;
  color: white;
  background: #abd4ce;
  border-radius: 18px;
 }

.nav li.current-page {
  background: rgba(255, 255, 255, 0.05); }

.nav li li li.current-page {
  background: none; }

.nav li li.current-page a {
  color: #fff; }

.nav.side-menu > li.active > a {
  text-shadow: rgba(0, 0, 0, 0.25) 0 -1px 0;
  background: -webkit-gradient(linear, left top, left bottom, from(#334556), to(#2C4257)), #2A3F54;
  background: linear-gradient(#334556, #2C4257), #2A3F54;
  -webkit-box-shadow: rgba(0, 0, 0, 0.25) 0 1px 0, inset rgba(255, 255, 255, 0.16) 0 1px 0;
  box-shadow: rgba(0, 0, 0, 0.25) 0 1px 0, inset rgba(255, 255, 255, 0.16) 0 1px 0; }

.navbar-brand, .navbar-nav > li > a {
  font-weight: 500;
  color: #ECF0F1 !important;
  margin-left: 0 !important;
  line-height: 32px; }
  
</style>
<div class="container body">
      <div class="main_container bg" >
        <div class="col-md-3 left_col bg" > 
          <div class="left_col scroll-view bg" style="position: fixed">
            <div class="navbar nav_title bg">
            </div>
            <div class="clearfix bg"></div>

            <!-- menu profile quick info -->
            <div class="profile clearfix">
              <div class="profile_pic">
              <center><img src="../build/images/logo.png" alt="..." width="150" style="margin-left: 35px"></center>
              </div>
            </div>
            <!-- /menu profile quick info -->
            <br />
            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu" >
              <div class="menu_section">
              <ul class="nav side-menu">
                <li><a href="index.php"><i class="fa fa-tachometer"></i> Dashboard</a></li>
                <li><a href="pharmacies.php"><i class="fa fa-hand-holding-medical"></i> Pharmacies</a></li>
                <li><a href="users.php"><i class="fa fa-user"></i>Pharmacy Users</a></li>
                <li><a href="medicines.php"><i class="fa fa-file-prescription"></i> Medicines</a></li>
                <!--<li><a href="report.php"><i class="fa fa-bar-chart"></i> Report</a></li>-->
                <li><a href="map.php"><i class="fa fa-map-location"></i> Map</a></li>
                </ul>
              </div>

            </div>
            <!-- /sidebar menu --