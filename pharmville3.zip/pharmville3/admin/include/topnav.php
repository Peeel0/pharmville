<?php 
?>

<!-- top navigation -->
<style>
.bg{
  background: #729b79;

}
.nav-md ul.nav.child_menu li:after {
  border-left: 1px solid #425668;
  bottom: 0;
  content: "";
  left: 27px;
  position: absolute;
  top: 0; }

.nav-md ul.nav.child_menu li:last-child::after {
  bottom: 50%; }

.nav.side-menu > li > a, .nav.child_menu > li > a {
  color: #000;
  font-weight: bolder; }

.nav.child_menu li li:hover,
.nav.child_menu li li.active {
  background: none; }

.nav.child_menu li li a:hover,
.nav.child_menu li li a.active {
  color: #fff;
 }

.nav > li > a {
  position: relative;
  display: block;
  padding: 13px 15px 12px; }

.nav.side-menu > li.current-page, .nav.side-menu > li.active {
  border-right: 5px solid #031d44;
  color: white;
  background: #abd4ce;
  border-radius: 18px;
 }

.nav li.current-page {
  background: rgba(255, 255, 255, 0.05); }

.nav li li li.current-page {
  background: none; }

.nav li li.current-page a {
  color: #fff; }

.nav.side-menu > li.active > a {
  text-shadow: rgba(0, 0, 0, 0.25) 0 -1px 0;
  background: -webkit-gradient(linear, left top, left bottom, from(#334556), to(#2C4257)), #2A3F54;
  background: linear-gradient(#334556, #2C4257), #2A3F54;
  -webkit-box-shadow: rgba(0, 0, 0, 0.25) 0 1px 0, inset rgba(255, 255, 255, 0.16) 0 1px 0;
  box-shadow: rgba(0, 0, 0, 0.25) 0 1px 0, inset rgba(255, 255, 255, 0.16) 0 1px 0; }

.navbar-brand, .navbar-nav > li > a {
  font-weight: 500;
  color: #ECF0F1 !important;
  margin-left: 0 !important;
  line-height: 32px; }
  
</style>
        <div class="top_nav">
          <div class="nav_menu">
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>
              <nav class="nav navbar-nav">
              <ul class=" navbar-right">
                <li class="nav-item dropdown open" style="padding-left: 15px;">
                  <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                    <img src="images/img.jpg" alt=""><?php echo $_SESSION['name']?>
                  </a>
                  <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item"  href="javascript:;"><i class="fa fa-user pull-right"></i> Profile</a>
                    <a class="dropdown-item" href="../index.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a>
                  </div>
                </li>
              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->