<!DOCTYPE html>
<html lang="en">
<?php
include 'include/dbconnection.php';
?>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="images/favicon.ico" type="image/ico" />

    <title>PharmVille</title>

    <!-- Bootstrap -->
    <link href="cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- Datatables -->
    <link href="../vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/306f6e1206.js" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>


<?php
if(isset($_SESSION['statuses']) && $_SESSION['statuses'] !=''){

    ?>
<script>
    Swal.fire({
        title: "<?php echo $_SESSION['statuses']; ?>",
        icon: "<?php echo $_SESSION['status_code']; ?>",
        button: "Okay",
        confirmButtonColor: "<?php echo $_SESSION['color']; ?>"

    });
    // swal("Good job!", "You clicked the button!", "success");
</script>
<?php 
    unset($_SESSION['statuses']);
}
?>

  <body class="nav-md">
            <?php include 'include/sidebar.php';?>
            <?php include 'include/menufooter.php';?>
          </div>
        </div>

        <?php include 'include/topnav.php';
          if (isset($_POST['addPharm']))
          {
            $pname = $_POST['pname'];
            $owner = $_POST['owner'];
            $address = $_POST['address'];
            $contact = $_POST['contact'];
            $email = $_POST['email'];
            
            $sql = "INSERT INTO `pharmacies`(`pname`, `owner`, `address`, `contact`, `email`) VALUES ('$pname','$owner','$address','$contact','$email')";
            $result = mysqli_query($con, $sql);
          
            if($result)
            {
              echo '<script type="text/javascript">
              swal({
              title: "Successfully Added!",
              icon: "success",
              button: "Close",
              });
              setTimeout(function(){location.reload(1)},3000000);
            </script>';
            
            }
            else {
              echo("Error description: ". mysqli_error($con));
            }
          }
          else if(isset($_POST['upPharmacy']))
          {
            $pname = $_POST['uppname'];
            $owner = $_POST['upowner'];
            $address = $_POST['upaddress'];
            $contact = $_POST['upcontact'];
            $email = $_POST['upemail'];
            $pharmid = $_POST['upID'];
            
            $sql = "UPDATE pharmacies SET pname = '$pname', owner = '$owner', address = '$address', contact = '$contact', email = '$email' WHERE ID = '$pharmid'";
            $result = mysqli_query($con, $sql);
          
            if($result)
            {
              echo '<script type="text/javascript">
                      swal({
                      title: "Successfully Updated!",
                      icon: "success",
                      button: "Close",
                      });
                      setTimeout(function(){location.reload(1)},3000000);
                    </script>';
            
            }
            else {
              echo("Error description: ". mysqli_error($con));
            }        
          }
          
          else if (isset($_GET['id']))
          {
            $id = $_GET['id'];
          
              $query = "DELETE FROM pharmacies WHERE ID = '$id' ";
              $query_run = mysqli_query($con, $query);
          
              if($query_run)
              {
                echo '<script type="text/javascript">
                    swal({
                    title: "Successfully Deleted!",
                    icon: "success",
                    button: "Close",
                    });
                    setTimeout(function(){location.reload(1)},3000000);
                </script>';
          
              }
              else {
                echo '<script type="text/javascript">
                    swal({
                    title: "Delete Failed!",
                    icon: "success",
                    button: "Close",
                    });
                    setTimeout(function(){location.reload(1)},3000000);
                </script>';
              }
          }
        ?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3><i class="fa fa-hand-holding-medical"></i> Pharmacies</h3>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>List of Pharmacies</h2>
                    <ul class="nav navbar-right panel_toolbox">
                    <a class="btn btn-sm btn-info text-white"  data-toggle="modal" data-target="#addPharm"><i class="fa fa-plus"></i> Add Pharmacy</a>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                  <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th style="display: none">ID</th>
                          <th>Store Name</th>
                          <th>Owner</th>
                          <th>Address</th>
                          <th>Contact Number</th>
                          <th>Email</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          $query="SELECT * FROM pharmacies";
                          $sql = mysqli_query($con,$query);
                          while($row = mysqli_fetch_assoc($sql)){
                        ?>
                        <tr>
                          <td style="display: none  "><?php echo $row["ID"];?></td>
                          <td><?php echo $row["pname"];?></td>
                          <td><?php echo $row["owner"];?></td>
                          <td><?php echo $row["address"];?></td>
                          <td><?php echo $row["contact"];?></td>
                          <td><?php echo $row["email"];?></td>
                          <td><a class="btn btn-sm btn-success text-white" data-toggle="modal" data-target="#editPharm<?php echo $row['ID']; ?>" id="editPharmacy"><i class="fa fa-edit"></i> </a>
                          <a href="pharmacies.php?id=<?php echo $row["ID"];?>" class="btn btn-sm btn-danger text-white"  onClick="return confirm('Are you sure you want to delete?')"><i class="fa fa-trash"></i></a>
                          </td>
                        </tr>

<!--modal-->
<div class="modal fade" id="editPharm<?php echo $row['ID']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Pharmacy</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="" method = "POST" id="upPharmModal">
        <div class="modal-body">
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
              <input type="hidden" class="form-control" name ="upID" id="upID" value="<?php echo $row["ID"];?>">

                <input type="text" class="form-control" name ="uppname" id="uppname" placeholder="" value="<?php echo $row["pname"];?>">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="upowner" id="upowner" placeholder="" value="<?php echo $row["owner"];?>">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="upaddress" id="upaddress" placeholder="" value="<?php echo $row["address"];?>">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="upcontact" id="upcontact" placeholder="" value="<?php echo $row["contact"];?>">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="upemail" id="upemail" placeholder="" value="<?php echo $row["email"];?>">
              </div>
            </div>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" name ="upPharmacy" id="upPharmacy">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>
<!--end modal-->

                        <?php
                          }
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

<!-- Modal -->
<div class="modal fade" id="addPharm" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Pharmacy</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="" method = "POST">
        <div class="modal-body">
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="pname" placeholder="Pharmacy Name">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="owner" placeholder="Name of Owner">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="address" placeholder="Address">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="contact" placeholder="Contact Number">
              </div>
            </div>
            <div class="item form-group">
              <div class="col-md-12 col-sm-12  form-group has-feedback">
                <input type="text" class="form-control" name ="email" placeholder="Email Address">
              </div>
            </div>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" name ="addPharm">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>
    <?php include 'include/footer.php';?>
  </body>
</html>

<?php
include 'include/script.php';
?>